# Clarity Assets

This repository is part of the [Clarity](https://github.com/vmware/clarity) project, and its purpose is to store the static assets that we provide for consumers of Clarity.

You are welcome to download the files from here, or you can find them listed our website https://clarity.design as well.

### Contents

**icons** contains the sets of icons from Clarity Icons
**sketch** contains the sketch files for designers crafting interfaces with Clarity