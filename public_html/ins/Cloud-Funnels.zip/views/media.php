<div id="cf_media_app" class="col-sm-12">
    <media_app v-bind:view='view'></media_app>
</div>