<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12 d-flex justify-content-center align-items-center" style="height: 60vh; flex-direction: column;">
        <h2 style="opacity: 0.6">This is a pro feature, please upgrade to continue.</h2>
        <a href="<?php echo $pro_upgrade_url; ?>" target="_BLANK" class="btn btn-primary theme-button" style="margin-top:10px"><i class="fas fa-unlock-alt"></i>&nbsp;&nbsp;Upgrade to Pro</a>
    </div>
  </div>
</div>