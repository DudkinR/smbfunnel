<div class="container-fluid">
<div class="row">
<div class="col-sm-12">
<div class="alert alert-warning"><strong>Hi, You Don't have Permission To Access This Page, Please Contact With Admin If You Believe This Is An Error.</strong></div>
</div>
</div>
</div>