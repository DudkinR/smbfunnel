<?php

phpinfo();

 ?>
