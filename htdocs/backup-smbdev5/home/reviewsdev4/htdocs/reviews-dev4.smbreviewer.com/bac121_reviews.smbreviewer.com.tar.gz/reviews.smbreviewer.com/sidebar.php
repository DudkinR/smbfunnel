<!-- start: sidebar -->
				<?php
                $currentPage = $_SERVER['PHP_SELF'];
                ?>

                <aside id="sidebar-left" class="sidebar-left">

					<div class="sidebar-header">
						<div class="sidebar-title" style="font-weight:bold;">
							Build Trust
						</div>
						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
						</div>
					</div>

					<div class="nano">
						<div class="nano-content">
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-main">

                                    <li class="<?php if($first_part=="campaign.php" || $first_part=="campaign_add.php"){ echo "nav-active"; } ?>" >
                                        <a href="campaign.php" class="waves-effect"><i class="fa fa-tachometer"></i><span> Campaigns </span></a>
                                    </li>

                                    <li class="<?php if($first_part=="custom_reviews.php" || $first_part=="custom_reviews_add.php"){ echo "nav-active"; } ?>" >
                                        <a href="custom_reviews.php" class="waves-effect"><i class="fa fa-star-half-o"></i><span> Custom Reviews </span></a>
                                    </li>





                                    <li class="nav-parent <?php if(in_array($first_part,array("settings.php","google_settings.php","paypal_settings.php","general_settings.php","yelp_settings.php"))){ echo " nav-expanded nav-active"; } ?>">
																			<a>
																				<i class="fa fa-gear" aria-hidden="true"></i>
																				<span>Settings</span>
																			</a>
																			<ul class="nav nav-children">
                                            <li class="<?php if($first_part=="settings.php"){ echo "nav-active"; } ?>">
                                                <a href="settings.php"><span>Facebook </span></a>
                                            </li>
                                            <li class="<?php if($first_part=="google_settings.php"){ echo "nav-active"; } ?>">
                                                <a href="google_settings.php"><span>Google </span></a>
                                            </li>
                                            <li class="<?php if($first_part=="yelp_settings.php"){ echo "nav-active"; } ?>">
                                                <a href="yelp_settings.php"><span>Yelp </span></a>
                                            </li>
                                            <?php

                                            if($_SESSION['type']=="1"){
                                            ?>
                                                <li class="<?php if($first_part=="paypal_settings.php"){ echo "nav-active"; } ?>">
                                                    <a href="paypal_settings.php"></i><span> Paypal </span></a>
                                                </li>
                                                <li class="<?php if($first_part=="general_settings.php"){ echo "nav-active"; } ?>">
                                                    <a href="general_settings.php"><span> General </span></a>
                                                </li>
                                            <?php
                                            }
                                          ?>
																			</ul>
																		</li>

                                    <?php

                                    if($_SESSION['type']=="1"){

                                    ?>



                                    <li class="<?php if($first_part=="members.php"){ echo "nav-active"; } ?>">
                                        <a href="members.php" class="waves-effect"><i class="fa fa-users"></i><span> Clients </span></a>
                                    </li>

                                    <li class="<?php if($first_part=="plans.php"){ echo "nav-active"; } ?>">
                                        <a href="plans.php" class="waves-effect"><i class="fa fa-money"></i><span> Pricing Plans </span></a>
                                    </li>

                                    <li class="<?php if($first_part=="payments.php"){ echo "nav-active"; } ?>">
                                        <a href="payments.php" class="waves-effect"><i class="fa fa-usd"></i><span> Payments </span></a>
                                    </li>

                                    <?php
                                    }
                                    ?>

                                    <li class="<?php if($first_part=="profile.php"){ echo "nav-active"; } ?>">
                                        <a href="profile.php" class="waves-effect"><i class="fa fa-user"></i><span> Profile </span></a>
                                    </li>

                                    <li class="<?php if($first_part=="tutorial.php"){ echo "nav-active"; } ?>">
                                        <a href="tutorial.php" target="_blank" class="waves-effect"><i class="fa fa-file-code-o"></i><span> Tutorial </span></a>
                                    </li>

                                                                        <li class="<?php if($first_part=="feature-request.php"){ echo "nav-active"; } ?>" >
                                        <a href="feature-requests.php" class="waves-effect"><i class="fa fa-lightbulb-o"></i><span> Feature Requests </span></a>
                                    </li>
                                    <li class="<?php if($first_part=="get-reviews.php"){ echo "nav-active"; } ?>" >
                                        <a href="get-reviews.php" class="waves-effect"><i class="fa fa-pencil-square"></i><span> Get Reviews</span></a>
                                    </li>
                                     <li class="<?php if($first_part=="get-reviews.php"){ echo "nav-active"; } ?>" >
                                        <a href="https://www.smbmeet.com" target="_blank" class="waves-effect"><i class="fa fa-users"></i><span>Community</span></a>
                                    </li>

																		<li class="visible-xs">
																			<a role="menuitem" tabindex="-1" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
																		</li>





                            
								</ul>
							</nav>

						</div>

					</div>

				</aside>
				<!-- end: sidebar -->
